/*

  !- Credits By ୧⍤⃝Tama Official
  https://wa.me/6285718333041
  
*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

//~~~~~~~~~~~ Settings Bot ~~~~~~~~~~~//
global.owner = '6285718333041'
global.versi = version
global.namaOwner = "୧⍤⃝Tama Official"
global.packname = 'Bot WhatsApp'
global.botname = 'Babu ୧⍤⃝Tama Official'
global.botname2 = 'jangan ganggu owner gua'

//~~~~~~~~~~~ Settings Link ~~~~~~~~~~//
global.linkOwner = "https://wa.me/6285718333041"
global.linkGrup = "https://chat.whatsapp.com/FgBj38H2LRL1YHUgCHTugw"

//~~~~~~~~~~~ Settings Jeda ~~~~~~~~~~//
global.delayJpm = 3500
global.delayPushkontak = 6000

//~~~~~~~~~~ Settings Saluran ~~~~~~~~~//
global.linkSaluran = "https://whatsapp.com/channel/0029Vb6sfQfHgZWfB5c0I610"
global.idSaluran = "120363389195304446@newsletter"
global.namaSaluran = "୧⍤⃝Tama Official"
global.thumb = "https://img12.pixhost.to/images/532/570920507_cupen.jpg"
//~~~~~~~~~ Settings Orderkuota ~~~~~~~~//
global.merchantIdOrderKuota = "OK2060177"
global.apiOrderKuota = "430694417318329852060177OKCT827C2279DDFCD8D6DD9E2D6C1BDC7D44"
global.qrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214009121195553790303UMI51440014ID.CO.QRIS.WWW0215ID20243485064430303UMI5204541153033605802ID5923ANGGARA STORE OK20601776013JAKARTA BARAT61051111062070703A01630444F6"

//~~~~~~~~~~ Settings Apikey ~~~~~~~~~~//
global.apiDigitalOcean = "dop_v1_36daabb24cd3b7862fe01c0e8e9013d8d0a48694d10bdf598f8cdb8a8f65e29c"
global.apiSimpleBot = "simplebotz85"

//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "082120066305"
global.ovo = "082128561404"
global.gopay = "082120066305"

//~~~~~~~~~~ Settings Image ~~~~~~~~~~//
global.image = {
menu: "https://img12.pixhost.to/images/532/570920507_cupen.jpg", 
reply: "https://img12.pixhost.to/images/532/570920507_cupen.jpg", 
logo: "https://img12.pixhost.to/images/532/570920507_cupen.jpg", 
qris: "https://img86.pixhost.to/images/455/562463470_cupenoffc.jpg"
}
//~~~~~~~~~ Settings Api Panel ~~~~~~~~//
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = ""
global.apikey = "" //ptla
global.capikey = "" //ptlc
//~~~~~~~~ Settings Api Panel 2 ~~~~~~~~//
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = ""
global.apikeyV2 = "" //ptla
global.capikeyV2 = "" //ptlc
//~~~~~~~~ Settings Api Panel 3 ~~~~~~~~//

global.eggV3 = "15" // Egg ID

global.nestidV2l3 = "5" // nest ID

global.locV3 = "1" // Location ID

global.domainV3 = ""

global.apikeyV3 = "" //ptla

global.capikeyV3 = "" //ptlc
// Settings Api Subdomain
global.subdomain = {
"cupencrew.my.id": {
"zone": "505292d6fa0c31a0f3c179e31da8e3f5", 
"apitoken": "yKkh3VluAjlvyy8i3VM_jw-Pjsq_liBv4QVJZrm0"
}, 
"cupentamvan.biz.id": {
"zone": "cde563dd21c04e2770bb66993dd667a3", 
"apitoken": "YPhb9lXkwFu0PrHgiT1XwQSyN5Rf3eAYiMdt0zJ9"
}, 
"cupenpendiem.shop": {
"zone": "a70c572f7c8f8bc0ad5ac2552e42e516", 
"apitoken": "VEtKD6sBAvgwQd1pYBV957Rno1feXoxqXPo1biij"
}, 
"skyzopedia.us.kg": {
"zone": "9e4e70b438a65c1d3e6d0e48b82d79de", 
"apitoken": "odilM9DpvLVPodbPyZwW7UcDKg1aIWsivJc0Vt_o"
}, 
"marketplace.us.kg": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
}, 
"xyz-store.biz.id": {
"zone": "8ae812c35a94b7bd2da993a777b8b16d", 
"apitoken": "oqZafkd3mSt1bABD9MMTidpCtD9VZdiPTjElVKJB"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
}, 
"xyro.web.id": {
"zone": "46d0cd33a7966f0be5afdab04b63e695", 
"apitoken": "CygwSHXRSfZnsi1qZmyB8s4qHC12jX_RR4mTpm62"
}, 
"xyroku.my.id": {
"zone": "f6d1a73a272e6e770a232c39979d5139", 
"apitoken": "0Mae_Rtx1ixGYenzFcNG9bbPd-rWjoRwqN2tvNzo"
}, 
"xyro.me": {
"zone": "a1c08ecd2f96516f2a85250b98850e8b", 
"apitoken": "f3IBOeIjRHYSsRhzxBO7yiwl-Twn3fqjmdkLdwlf"
}, 
"cloud-shopp.biz.id": {
"zone": "365f57282cbea3a6d5a738f107df244e", 
"apitoken": "hZKxD6afDLF-wsg1qVA-qbDK_h8lBE4NtqnVZPP8"
},
"serverpanell.biz.id": {
"zone": "225512a558115605508656b7bdf29b28", 
"apitoken": "XasxSSnGp8M9QixvT6AAlh1vEm4icVgzDyz7KDiF"
},
"market-panel.site": {
"zone": "d06bf5450ae51612a400bab1c4450283",
"apitoken": "kmb6AkpJ6XvHMzw2m0KbYKZOycIURNYMPA7Wm0BE",
},
"admin-panel.tech": {
"zone": "305d4757160a88486d3780785c7c9887",
"apitoken": "UH-aDtxu5Mm9oU8khMd5ZVg22f7nhnSkCORBn8zP",
},
"kang-panel.tech": {
"zone": "28baf36eb9ced4be271bdb6ea3320f41",
"apitoken": "MBiKuyoS0e0zJc8LKUjSXyLmgAf1IV9u86FJmVny",
},
"web-cabul.me": {
"zone": "4b24636040f0f2d799a8a1aaea568e57",
"apitoken": "OvRX-DghNjcPF9rlKElGCLIsPvv3Nd3khuDAUZ3q",
},
"king-hosting.live": {
"zone": "2e6eb183148e0ef9add390af271a8bb2",
"apitoken": "kcnnE1sESybx-P_nLkkiKtfZFqGhRmwFg9wL0cf6",
},
"tokopanel.software": {
"zone": "cc9638d4c289130ba070484625e6aefa",
"apitoken": "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs",
},
"pannel-private.me": {
"zone": "71ad41d3c25085bd7b8a1135632c7c63",
"apitoken": "HfGKPUu1KrOVc3q51nkoJYZFQvIpA-AFOP-t6SNZ",
},
"hitam.systems": {
"zone": "cfaba3ef0065acc82facc17f1b79d50b",
"apitoken": "4o3tZAc5jOzA00joKpLYhG_616qCJxNLGlhawMEY",
},
"panel-run-bot.engineer": {
"zone": "678298eaac2e2a0dea25f693310ec6e0",
"apitoken": "8UmNiZZqEIAqWbM7XlcZofyvhc70NMs2_gXmmkug",
},
"uchiha.tech": {
"zone": "1b09e81ec29d760ff33e476a084de6ed",
"apitoken": "nzLwv-2uzMt3Ihsd5MVV2aLJ9EoovxrVK7Y4b2To",
},
"buyer-vps.site": {
"zone": "354e1c784bed5a8d93f458ec1ff86f35",
"apitoken": "rzOLIO1c-Me1X0owStLFUZ0ggfs_cxHDab2A7krF",
},
"arzanoffc.online": {
"zone": "43ca801f5c6a73a77da5f0243f4f8c1d",
"apitoken": "RZQft_gJGOJDskx6L6SxREJCvOKw0hclLjHUCNLS",
},
"hexaneuro.biz.id": {
"zone": "16273869fda58585fc435e4582a5ff56",
"apitoken": "y4wV0um-bvrVTvFVPrNrGEi590bPowvosRyNiGMn"
 },   
"mypanel.tech": {
"zone": "9c5460deca7c84273b46f2f047783636",
"apitoken": "0IBfmlUlCkYqoFPWYaqCmqI3_vWxkrFNbxrQjzX2"
}, 
"kedai-panel.me": {
"zone": "3ab91ea96368234719c9de7d260742e2",
"apitoken": "O22A19W7trZZ52bAXtF77aUVdGDdAk8PjQqwM7qv"
}, 
"control-pannel.site": {
"zone": "20c517d7dcc25d9cf516f5c4cf2d21ba",
"apitoken": "mAA84Qs4nJvLTaup0HTGrpVbgaSk-4vfUrcdHgCH"
}, 
"mypanelstore.xyz": {
"zone": "72f7362d7686d9158a8e389851fc379c", 
"apitoken": "V2y-I2o1s5E1tdCPpUSnT4FokV6WuxEUC2FqqVIX"
},
"panel-pvrt.my.id": {
"zone": "ee4060e03b223e8e0724908575b70c3b", 
"apitoken": "6HxTQ0VJZVcAJISlKsezttCNzpAAf7ubPy5EDOGR"
},
"ekiofficial.my.id": {
"zone": "df33365b44b11cbe51570a7ed981cae5", 
"apitoken": "rMJGbyeuwFVZJifsB3rIX-nRpIOOa4Wkrhu7V5Jo"
},
"ekiofficial.web.id": {
"zone": "e1b037c00268cae95076b58f7f78b1f6", 
"apitoken": "EJO7mHrBORH9XoQrnUvBqotMYxNm5bjB5UO2PeQE"
},
"eki-panelpvrt.my.id": {
"zone": "6b4cb792b77b6118e91d8604253ca572", 
"apitoken": "DsftwwFCAKrbSo-9r9hxqcscMw8Xvx8gQzTXMSz4"
},
"panelvip.biz.id": {
"zone": "70969a584446a244efe1461f5bb41ff5", 
"apitoken": "pzj2mcvQL1KUQCjj5XjSVPjLqKGCy8U7PtVFuOXr"
},
"shop-panel.biz.id": {
"zone": "62e0683ee057e0e2a39eaf73d18e6eb1", 
"apitoken": "opUN9xsI7mlS3CP8cJA9RbO5SB4gUpcyof9Yaeb7"
},
"centzzcloud.my.id": {
"zone": "749f1d7d69e9329195761b570010c00f", 
"apitoken": "9Su8A1EDXnt9-yGDb7YSGlY_ogJAw2vR9IDtpFrQ"
},
"pakvinsen.me": {
"zone": "3b8cb89265c0e026abaf3bc50ed57e76", 
"apitoken": "ttt0IHK50UKP2HltWUauuyDzkVPqnOEkx7M-5CFs"
},
"satoruuhost.tech": {
"zone": "086b2b4e1c65c22bfd8d5d86cbfa947f", 
"apitoken": "62XZSKEzz4mKM_1wAHK7-_JaA14VrQJDoWI2GeHT"
},
"hostsatoruu.biz.id": {
"zone": "30ea1aac05ca26dda61540e172f52ff4", 
"apitoken": "eZp1wNcc0Mj-btUQQ1cDIek2NZ6u1YW1Bxc2SB3z"
},
"mafiapnel.my.id": {
"zone": "34e28e0546feabb87c023f456ef033bf", 
"apitoken": "bHNaEBwaVSdNklVFzPSkSegxOd9OtKzWtY7P9Zwt"
},
"rexxaoffc.my.id": {
"zone": "f972ed410a833b28c8b5f166d6620d6a", 
"apitoken": "liq8sBPHwvbU2jWQYTCjo4BXafVPeopkAU4avUlP"
}, 
"rexxa.my.id": {
"zone": "b0d37cb6e9d6a7c2b0a82395cbdfd8b9", 
"apitoken": "fR2LO4Hz2y0U8dP3IHRwMHnWi_xKKa5RCZjWaXv3"
},
"gacorr.biz.id": {
"zone": "cff22ce1965394f1992c8dba4c3db539", 
"apitoken": "v9kYfj5g2lcacvBaJHA_HRgNqBi9UlsVy0cm_EhT"
},
"cafee.my.id": {
"zone": "0d7044fc3e0d66189724952fa3b850ce", 
"apitoken": "wAOEzAfvb-L3vKYE2Xg8svJpHfNS_u2noWSReSzJ"
}, 
"store-panell.my.id": {
"zone": "0189ecfadb9cf2c4a311c0a3ec8f0d5c", 
"apitoken": "eVI-BXIXNEQtBqLpdvuitAR5nXC2bLj6jw365JPZ"
}, 
"vipstoree.my.id": {
"zone": "72fd03404485ddba1c753fc0bf47f0b3", 
"apitoken": "J2_c07ypFEaen92RMS7irszQSrgZ_VFMfgNgzmp0"
}, 
"bokepp.biz.id": {
"zone": "46b8cab5631c6c23c5ec4a7ef1f10803", 
"apitoken": "A8df8PxnKIcxLUTE7XS4TRZBoLslvt4XjJb1XEyi"
}, 
"market-store.my.id": {
"zone": "4ae70eaa56096fdb94ef9050dde52220", 
"apitoken": "_T1fxXQLd6864mYGwgHmciZMiLURKNkyomaPv0sy"
},
"shop-panel.biz.id": {
"zone": "62e0683ee057e0e2a39eaf73d18e6eb1",
"apitoken": "opUN9xsI7mlS3CP8cJA9RbO5SB4gUpcyof9Yaeb7"
},
"pterodaytl.my.id": {
"zone": "828ef14600aaaa0b1ea881dd0e7972b2",
"apitoken": "75HrVBzSVObD611RkuNS1ZKsL5A_b8kuiCs26-f9"
},
"wannhosting.biz.id": {
"zone": "4e6fe33fb08c27d97389cad0246bfd9b",
"apitoken": "75HrVBzSVObD611RkuNS1ZKsL5A_b8kuiCs26-f9"
},   
"wannhosting.my.id": {
"zone": "0b36d11edd793b3f702e0591f0424339",
"apitoken": "OsSjhDZLdHImYTX8fdeiP1wocKwVnoPw5EiI85IF"
}, 
"xnxxx.tech": {
"zone": "639f9cde20c22b1d2f33b2fee54f8f59",
"apitoken": "MtWI3a9-9Za-fGKmwl0uNznqM94eljKgobkF36h1"
},
"pterodactyl-panel.web.id": {
"zone": "d69feb7345d9e4dd5cfd7cce29e7d5b0",
"apitoken": "32zZwadzwc7qB4mzuDBJkk1xFyoQ2Grr27mAfJcB"
},
"panelprivate.web.id": {
"zone": "61bcd80ff1ec9c3a5812f74d6ec24535",
"apitoken": "VnjVDtbb-fSTFIn-3Hckd_E_eseqyHH7u1TTAHMN"
},
"serverpanell.biz.id": {
"zone": "aac5555d4f60fcf48c9e901b938fffc0", 
"apitoken": "qd8OolI2_GIu3HLsTZvdk242ggDdD3_IGXMMSQ7P"
}, 
"privatehost.us.kg": {
"zone": "790918217c4add75b7684458518c5836", 
"apitoken": "qYv4NvEN6ZcUIv4dEXihjkmQMwbP_-3Qy_zFlAHv"
}, 
"botwhatsapp.us.kg": {
"zone": "fb1ac418c5564373a56c91d962b30dca", 
"apitoken": "rfQih0XNXiq7AyEuDoLjoFfHX2mhYf_9kddAdKIo"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ZPAXx7CL51PtbGweL2pE3BsI3x0hgTgLuy56iXuo"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "HXVf4soYFM3iiOewHZ6tk6LEnG9f7m7CVhU0EoVz"
}, 
"xyz-store.biz.id": {
"zone": "8ae812c35a94b7bd2da993a777b8b16d", 
"apitoken": "oqZafkd3mSt1bABD9MMTidpCtD9VZdiPTjElVKJB"
}, 
"rafatharxamalia.my.id": {
"zone": "eadca8b2f2c8b93a8413b8594ad7ef48", 
"apitoken": "GEl7ZdaTnJuJJMjNQbT2nsf__hPxr4DumLbMD2xa"
}, 
"tokopanelku.my.id": {
"zone": "1acc96e9e3be7da6799d49b7927678bf", 
"apitoken": "GMiEVWZ5xO843jjfZeDORZIDgEnnJ5Yo3yXkiB"
}, 
"manzz.my.id": {
"zone": "8acff3a918a2433e53162c952b7dcfb5", 
"apitoken": "hxQuBudz9oiKcvoIGhKO7lZDxlQuDTOPXbRwEb4K"
}, 
"xpanelprivate.biz.id": {
"zone": "f838b3f6d24b7167026e4db197d5689a", 
"apitoken": "IhfT4A4ORNgl0uO9U7uUKbDoefqF3xTpJ-NLk6Lt"
},
"roompanelpriv.my.id": {
"zone": "73f4d0171fe1f48db80aed6323e9330d",
"apitoken": "2c29LWyyTHGXNtccxA62QWCGmxRcLoGcB9Y35jrH"
},
"hilman-store.web.id": {
"zone": "4e214dfe36faa7c942bc68b5aecdd1e9",
"apitoken": "wpQCANKLRAtWb0XvTRed3vwSkOMMWKO2C75uwnKE"
},
"paneldigital.web.id": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
},
"digital-market.web.id": {
"zone": "652c4800932a51249d42099dcfd55d0d", 
"apitoken": "wUQ8mx8_thiR0lq_sZ0bhyEjdo-UIs9iZojgTi7g"
},
"hilmanzoffc.web.id": {
"zone": "2627badfda28951bfb936fce0febc5b0",
"apitoken": "wZ3QAKn7zDx-tyb04HgCvmogqeM6je8jDNmiPZXq"
},
"hostingers-vvip.my.id": {
"zone": "2341ae01634b852230b7521af26c261f",
"apitoken": "Ztw1ouD8_lJf-QzRecgmijjsDJODFU4b-y697lPw"
},
"panelstore-vvip.biz.id": {
"zone": "a99445e7459f95735af8e44f43b03834",
"apitoken": "pOKX689oVlJCQBq1awwHkok-o3cKyOEk6vq8AGoe"
},
"hilmanofficial.tech": {
"zone": "c8705bfbfdca9c4e8e61eb2663ee87d6",
"apitoken": "hjqWa_eFAfoJNJyBu9WAlg8WO0ICtN5AYpZURgqe"
}
}

//~~~~~~~~~~ Settings Message ~~~~~~~~//
global.mess = {
	owner: "*[ Akses Ditolak ]*\nFitur ini hanya untuk owner bot!",
	admin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk admin grup!",
	botAdmin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam grup!",
	private: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam private chat!",
	prem: "*[ Akses Ditolak ]*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})